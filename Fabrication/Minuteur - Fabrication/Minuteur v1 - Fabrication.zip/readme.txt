Hello,

This is a new version of the Minuteur-board.
Some modifications needed to be made after testing of those I made with order #58458, so somes tracks have been re-routed.

I tried to organize a bit better the silkscreens so to avoid minor errors like a resistor and a capacitor that were swapped last time. I've included as well a FAB-layer (Minuteur-F.Fab.gbr) which sole purpose is to provide you informations if needed.

As in the first version I've ordered from you, there is a cut out inside the board to provide a better isolation between logic CC and power AC. It's placed in the area where there's no ground plane, and of course present on the cutout file (Minuteur-Edge.Cuts.gm1)

Please feel free to ask any question you could have.